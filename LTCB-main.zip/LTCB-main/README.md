<h1>Current unsolved exercises:</h1>
<ol>
  <li>Phần hàm:
    <ol>
      <li>Bài 6</li>
    </ol>
  </li>
</ol>  

![https://youtu.be/SjOWnLlFMvM?si=iT1VXm0hnSYIaclE](https://i.kym-cdn.com/photos/images/newsfeed/002/347/436/640.jpg)\
<p> what oh my god 😱 it's a stop sign ⛔ finding nemo 🐡 gold fish 🐠 Dory 🐟 NATIONAL GEOGRAPHIC 🟨 GODDAMN IT </p>
